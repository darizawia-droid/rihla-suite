/**
 * Configuration par rôle :
 * - homeRoute : page d'accueil après login
 * - navGroups : navigation affichée dans la sidebar
 */

export type AppRole =
  | 'super_admin'
  | 'sales_director'
  | 'travel_designer'
  | 'quotation_officer'
  | 'data_operator'
  | 'sales_agent'
  | 'guide'
  | 'client'
  | 'driver'

export function getHomeRoute(role: string): string {
  const map: Record<string, string> = {
    super_admin:      '/dashboard',
    sales_director:   '/portal/horizon',
    travel_designer:  '/projects',
    quotation_officer:'/invoices',
    data_operator:    '/inventory/hotels',
    sales_agent:      '/projects',
    guide:            '/portal/guide',
    client:           '/portal',
    driver:           '/portal/driver',
  }
  return map[role] ?? '/dashboard'
}

export interface NavItem {
  to: string
  label: string
  icon: string   // Lucide icon name
  shortcut?: string
}

export interface NavGroup {
  label: string
  items: NavItem[]
}

const ALL_GROUPS: NavGroup[] = [
  {
    label: 'EXECUTIVE DASHBOARD',
    items: [
      { to: '/dashboard',            icon: 'LayoutDashboard', label: 'Pilotage Général',        shortcut: '1' },
      { to: '/analytics',            icon: 'BarChart3',       label: 'Performance Insights',    shortcut: 'A' },
      { to: '/crm',                  icon: 'Users',           label: 'Gestion Agences B2B',     shortcut: 'V' },
      { to: '/cash-pulse',           icon: 'Landmark',        label: 'Cash Pulse · Finance',    shortcut: '$' },
      { to: '/war-room',             icon: 'Radio',           label: 'War Room · Ops',          shortcut: 'W' },
    ],
  },
  {
    label: 'CŒUR DE MÉTIER (DMC)',
    items: [
      { to: '/projects',             icon: 'FolderKanban',    label: 'Dossiers & Projets',      shortcut: '2' },
      { to: '/travel-designer',      icon: 'Compass',         label: 'Travel Designer',         shortcut: 'T' },
      { to: '/quotations',           icon: 'Calculator',      label: 'Cotation Globale',        shortcut: '4' },
      { to: '/cotation-advanced',    icon: 'Calculator',      label: 'Cotation Avancée' },
      { to: '/itineraries',          icon: 'MapPin',          label: 'Concepteur Itinéraires',  shortcut: '3' },
      { to: '/export-excel',         icon: 'FileSpreadsheet', label: 'Export Excel' },
      { to: '/what-if',              icon: 'Sliders',         label: 'Simulation What-If' },
    ],
  },
  {
    label: 'STUDIO CRÉATIF & IA',
    items: [
      { to: '/proposal-studio',      icon: 'FileText',        label: 'Proposal Designer',       shortcut: 'P' },
      { to: '/circuit-generator',    icon: 'Sparkles',        label: 'Générateur IA',           shortcut: 'G' },
      { to: '/itinerary-search',     icon: 'History',         label: 'Mémoire & Recherche',     shortcut: 'M' },
      { to: '/ai-concierge',         icon: 'MessageCircle',   label: 'Concierge IA Hub',        shortcut: '@' },
    ],
  },
  {
    label: 'LOGISTIQUE & OPÉRATIONS',
    items: [
      { to: '/portal/horizon',       icon: 'Bus',             label: 'HORIZON Transport',       shortcut: 'Z' },
      { to: '/operations',           icon: 'Building2',       label: 'Suivi Terrain',           shortcut: 'L' },
      { to: '/operations/calendar',  icon: 'Calendar',        label: 'Planning Global',         shortcut: 'K' },
      { to: '/fleet-optimizer',      icon: 'Truck',           label: 'Flotte Véhicules',        shortcut: 'F' },
      { to: '/passengers',           icon: 'Users',           label: 'Gestion Passagers' },
    ],
  },
  {
    label: 'RÉSEAU & ACHATS (PROCURE)',
    items: [
      { to: '/inventory/hotels',     icon: 'Hotel',           label: 'Parc Hôtelier',           shortcut: 'H' },
      { to: '/inventory/guides',     icon: 'Compass',         label: 'Réseau Guides',           shortcut: 'G' },
      { to: '/inventory/restaurants',icon: 'Utensils',        label: 'Partenaires Resto',       shortcut: 'R' },
      { to: '/activities',           icon: 'Star',            label: 'Catalogue Activités',     shortcut: 'Y' },
      { to: '/allotments',           icon: 'Hotel',           label: 'Allotements' },
      { to: '/supplier-scoring',     icon: 'Award',           label: 'Scoring Fournisseurs' },
    ],
  },
  {
    label: 'GESTION & FINANCE',
    items: [
      { to: '/invoices',             icon: 'Receipt',         label: 'Facturation & Flux',      shortcut: '5' },
      { to: '/reports',              icon: 'BarChart2',       label: 'Reporting Avancé',        shortcut: '6' },
      { to: '/budget-tracker',       icon: 'BarChart2',       label: 'Budget Tracker' },
      { to: '/forex',                icon: 'TrendingUp',      label: 'Forex Dashboard',         shortcut: 'X' },
      { to: '/erp-integrations',     icon: 'Plug',            label: 'SAP & ERP Bridge',        shortcut: 'E' },
    ],
  },
  {
    label: 'B2B & EXPÉRIENCE CLIENT',
    items: [
      { to: '/client-portal',        icon: 'Globe',           label: 'Portail Client B2C' },
      { to: '/whatsapp',             icon: 'MessageCircle',   label: 'WhatsApp Hub' },
      { to: '/operations/concierge', icon: 'Gem',             label: 'Conciergerie VIP',        shortcut: 'J' },
    ],
  },
  {
    label: 'RESSOURCES MUTUALISÉES',
    items: [
      { to: '/itinerary-templates',  icon: 'Copy',            label: 'Templates Circuits' },
      { to: '/media-library',        icon: 'ImageIcon',       label: 'Médiathèque' },
      { to: '/document-templates',   icon: 'FileText',        label: 'Documents Types' },
      { to: '/references',           icon: 'Hash',            label: 'Références' },
    ],
  },
]

// Groupes visibles par rôle
const ROLE_GROUPS: Record<string, string[]> = {
  super_admin: [
    'EXECUTIVE DASHBOARD',
    'CŒUR DE MÉTIER (DMC)',
    'STUDIO CRÉATIF & IA',
    'LOGISTIQUE & OPÉRATIONS',
    'RÉSEAU & ACHATS (PROCURE)',
    'GESTION & FINANCE',
    'B2B & EXPÉRIENCE CLIENT',
    'RESSOURCES MUTUALISÉES',
  ],
  sales_director: [
    'EXECUTIVE DASHBOARD',
    'LOGISTIQUE & OPÉRATIONS',
    'RÉSEAU & ACHATS (PROCURE)',
    'GESTION & FINANCE',
  ],
  travel_designer: [
    'CŒUR DE MÉTIER (DMC)',
    'STUDIO CRÉATIF & IA',
    'LOGISTIQUE & OPÉRATIONS',
    'RÉSEAU & ACHATS (PROCURE)',
    'RESSOURCES MUTUALISÉES',
  ],
  quotation_officer: [
    'CŒUR DE MÉTIER (DMC)',
    'GESTION & FINANCE',
  ],
  data_operator: [
    'RÉSEAU & ACHATS (PROCURE)',
    'RESSOURCES MUTUALISÉES',
  ],
  sales_agent: [
    'CŒUR DE MÉTIER (DMC)',
    'B2B & EXPÉRIENCE CLIENT',
  ],
  guide: [],    // Utilise AppShellMobile
  client: [],   // Utilise AppShellMobile
  driver: [],   // Utilise AppShellMobile
}

// Items spécifiques rôles simples (guide, client, driver)
const MOBILE_NAV: Record<string, NavItem[]> = {
  guide: [
    { to: '/portal/guide',     icon: 'Calendar', label: 'Mon Agenda' },
    { to: '/notifications',    icon: 'Bell',      label: 'Notifications' },
  ],
  client: [
    { to: '/portal',           icon: 'Globe',     label: 'Mon Voyage' },
    { to: '/portal',           icon: 'Star',      label: 'Mes Avis' },
    { to: '/notifications',    icon: 'Bell',      label: 'Notifications' },
  ],
  driver: [
    { to: '/portal/driver',    icon: 'Car',       label: 'Mes Courses' },
    { to: '/notifications',    icon: 'Bell',      label: 'Notifications' },
  ],
}

export function getNavGroups(role: string): NavGroup[] {
  const allowed = ROLE_GROUPS[role] ?? ROLE_GROUPS.sales_agent
  return ALL_GROUPS.filter(g => allowed.includes(g.label))
}

export function getMobileNav(role: string): NavItem[] {
  return MOBILE_NAV[role] ?? []
}

export function isMobileRole(role: string): boolean {
  return ['guide', 'client', 'driver'].includes(role)
}

export const ROLE_LABELS: Record<string, string> = {
  super_admin:      'CEO',
  sales_director:   'Directeur Transport',
  travel_designer:  'Travel Designer',
  quotation_officer:'Directeur Financier',
  data_operator:    'Opérateur Data',
  sales_agent:      'Commercial',
  guide:            'Guide',
  client:           'Client',
  driver:           'Chauffeur',
}
